# EV Android Assistant — Phase 2

This project continues the uploaded Phase 1 project. Phase 2 adds a Gemini conversational brain, encrypted API-key storage, persistent memory, and recent conversation context. Existing Phase 1 voice commands, phone-control code, and Room reminders are retained.

## Phase 2 features added

- Gemini 2.5 Flash `generateContent` integration over HTTPS.
- API key entry in the EV screen; the key is stored locally with AndroidX EncryptedSharedPreferences. Do not share your key or commit it to GitHub.
- Hindi/Hinglish/English assistant prompt and concise voice responses.
- Room database upgraded from version 1 to version 2 using a migration, preserving the existing reminders table.
- Explicit voice memory commands:
  - `EV yaad rakho bike: Yamaha SZR`
  - `EV kya yaad hai`
  - `EV bhool jao bike`
- Last 10 conversation messages are supplied as context to Gemini. Conversation records older than 30 days are cleaned when the AI is used.
- Offline-first routing: existing local commands are parsed and executed before Gemini. If Gemini is unavailable, local phone controls and reminders remain available.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.
- Phase 1 exact-alarm API check guarded for Android 12+ to avoid calling the API on older Android versions.

## Build using GitHub Actions (recommended from phone)

1. Create/open a GitHub repository and upload the contents of this `EV` folder to its root (the folder containing `settings.gradle.kts`).
2. Push to `main` or `master`, or open **Actions → EV Android Build → Run workflow**.
3. Wait for the workflow to finish. A green check means Gradle produced the APK.
4. Open the completed workflow run → **Artifacts** → download `EV-phase2-debug-apk`.
5. Extract `app-debug.apk` and install it on the OPPO phone. Android may ask you to allow installation from that source.

The workflow uses Gradle 8.9 and Java 17. This project currently does not include a Gradle Wrapper; the workflow installs Gradle on the GitHub runner.

## Android Studio build

Open this folder (`EV`) in Android Studio, let Gradle sync, then run **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Use JDK 17 and Gradle 8.9.

## Gemini API setup

1. Create an API key in Google AI Studio using your own Google account.
2. Open EV → paste the key into **PHASE 2 · GEMINI BRAIN** → **Save key**.
3. Speak an unknown question after the EV wake phrase. The app sends that text and recent conversation context to Gemini over HTTPS.
4. Keep the key private. The key is encrypted in app-private storage, but anyone with access to an unlocked/rooted device or a compromised app can potentially access app data. Rotate the key if exposed.

Gemini requires internet and may return quota, model availability, or regional errors. The selected model is `gemini-2.5-flash`; update `GeminiClient.kt` if Google changes model availability. No API key is included in this ZIP.

## Test checklist

- [ ] Gradle sync succeeds.
- [ ] Debug APK builds in GitHub Actions.
- [ ] App launches on OPPO K13x 5G / Android 15.
- [ ] Start/stop voice service and grant microphone/notification permissions.
- [ ] Torch, volume, brightness, app launch, battery, device info still work.
- [ ] Existing reminders still exist after app upgrade; create and receive a test reminder.
- [ ] Save a Gemini key and confirm it remains after closing/reopening the app.
- [ ] Ask a simple question online and confirm Hindi/Hinglish answer.
- [ ] Try memory save/read/delete commands.
- [ ] Turn off internet and confirm local commands and reminders still work.

## Important limitations / honest status

- Source code has been updated, but this environment does not have Android SDK/Gradle installed, so **this ZIP has not been compiled or run-tested here**. Run the GitHub Actions build before installing. Fix any compiler/build errors before calling it a working APK.
- SpeechRecognizer is still the Phase 1 recognizer loop, not a dedicated low-power hotword engine. Screen-off listening can be stopped by ColorOS battery management.
- Barge-in is still partial-result based; it is not true full-duplex audio with echo cancellation.
- Gemini currently answers questions; it does not receive arbitrary phone-control tools. Existing allowlisted local commands continue to run locally. Calls, SMS, camera vision, screen vision, news/weather/maps, music, and smart-home controls remain future phases.
- Android/ColorOS may restrict background microphone use, exact alarms, and settings changes. EV does not bypass Android security or permission prompts.

## Project details

- Package: `com.abhishek.ev`
- Min SDK: 26
- Target SDK: 35
- Java: 17
- Kotlin: 2.0.21
- Android Gradle Plugin: 8.7.3


## Phase 3 additions — Communication (starter integration)
Added safe dialer/SMS composer helpers and a simple family-priority contact policy.
Calls open the dialer; SMS opens the system composer. Direct SMS helper is optional and
requires runtime permission plus explicit confirmation. No automatic calls, covert recording,
or silent message sending. These helpers are not yet wired into voice routing or UI.



## Phase 4 additions — Vision consent scaffolding
Added a system MediaProjection consent-intent helper and a system-camera launcher.
These are privacy-first entry points, not a complete live vision pipeline. CameraX/OCR/object
recognition, MediaProjection result handling, frame analysis, UI controls, and voice integration
remain to be implemented and tested. Screen capture always requires Android's visible consent.



## Phase 5 additions — Information services
Added Open-Meteo current weather client, an RSS feed parser for user-selected HTTPS feeds,
and a Google Maps navigation launcher. Location permission/consent and UI/voice integration
remain to be wired. Weather/network responses require internet and are not available offline.



## Phase 6 additions — Media and smart-home connectors
Added a local audio playback helper for user-selected media URIs, a notification-access settings
shortcut, and an optional Home Assistant REST client. The user must configure a secure HTTPS
server and token; never commit tokens. These are connector building blocks, not a finished
smart-home dashboard or autonomous automation engine. Notification listener service and UI
integration remain to be implemented.


## Build / validation status
- Source ZIP generated as a development handoff. It has NOT been compiled or tested on a device in this environment.
- Phase additions are starter modules and are not yet connected to EV's voice command router or Compose screens unless explicitly stated above.
- Do not treat a feature as complete until permissions, lifecycle, error handling, UI confirmation, and on-device tests pass.


## Build APK with GitHub Actions

1. Create or open your GitHub repository.
2. Upload the **contents of this EV folder** to the repository root (so `app/`, `build.gradle.kts`, and `.github/` are at the top level).
3. Open **Actions** and run **EV Android Build** (or push to `main`/`master`).
4. When the workflow succeeds, open the run and download the `EV-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone.

This workflow builds a debug APK. It does not mean every scaffolded Phase 3–6 feature is fully integrated or tested.
