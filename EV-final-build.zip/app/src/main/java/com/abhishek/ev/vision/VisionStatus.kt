package com.abhishek.ev.vision

data class VisionStatus(
    val cameraPermissionGranted: Boolean,
    val screenCaptureConsented: Boolean,
    val isCapturing: Boolean = false
)
