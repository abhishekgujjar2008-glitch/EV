package com.abhishek.ev.communication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager

/**
 * Phase 3 safe communication helpers.
 * Call/SMS actions are prepared for explicit user confirmation; this class does not
 * silently call or send messages. Direct SMS requires SEND_SMS permission and runtime consent.
 */
class CallSmsActions(private val context: Context) {
    fun openDialer(number: String) {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun prepareSms(number: String, message: String) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}"))
            .putExtra("sms_body", message)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun findContactName(name: String): String? {
        val cursor = context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts.DISPLAY_NAME),
            "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
        ) ?: return null
        return cursor.use { if (it.moveToFirst()) it.getString(0) else null }
    }

    /** Optional direct SMS path. Caller must request SEND_SMS at runtime and confirm first. */
    fun sendSmsAfterConfirmation(number: String, message: String) {
        @Suppress("DEPRECATION")
        val manager = context.getSystemService(SmsManager::class.java)
        manager.sendTextMessage(number, null, message, null, null)
    }
}
