package com.abhishek.ev.information

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

data class WeatherSummary(val temperatureC: Double, val windKph: Double, val weatherCode: Int)

class WeatherClient {
    /** Open-Meteo public forecast endpoint; caller supplies coordinates and obtains location consent separately. */
    suspend fun current(latitude: Double, longitude: Double): Result<WeatherSummary> = withContext(Dispatchers.IO) {
        runCatching {
            require(latitude in -90.0..90.0 && longitude in -180.0..180.0)
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,wind_speed_10m,weather_code"
            val text = URL(url).openConnection().apply {
                connectTimeout = 8000
                readTimeout = 10000
            }.getInputStream().bufferedReader().use { it.readText() }
            val current = JSONObject(text).getJSONObject("current")
            WeatherSummary(
                current.getDouble("temperature_2m"),
                current.getDouble("wind_speed_10m"),
                current.getInt("weather_code")
            )
        }
    }
}
