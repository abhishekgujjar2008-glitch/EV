package com.abhishek.ev.brain

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Online conversational brain. It only generates text; it cannot execute arbitrary phone actions. */
class GeminiClient(private val context: Context) {
    suspend fun ask(question: String, memoryContext: String, recentHistory: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val key = SecureKeyStore.get(context)
        if (key.isBlank()) return@withContext "Gemini API key set nahi hai. EV app mein Gemini API key save karo."

        val contents = JSONArray()
        val system = "You are EV, Abhishek's helpful Android voice assistant. Reply naturally in the user's language, usually Hindi/Hinglish, concise and clear. Address him as Abhishek or bhai naturally. Never claim a phone action happened; this chat endpoint cannot control the phone. If asked to do a phone action, explain that supported local commands are handled separately. Use saved memories only when relevant. If unsure, say so.\nSaved memory:\n$memoryContext"
        val historyText = recentHistory.takeLast(8).joinToString("\n") { (role, text) -> "$role: $text" }
        val prompt = buildString {
            append(system)
            if (historyText.isNotBlank()) append("\nRecent conversation:\n").append(historyText)
            append("\nUser: ").append(question)
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + URLEncoder.encode(key, "UTF-8")
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 25000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                return@withContext when (code) {
                    400, 403 -> "Gemini API key ya request mein problem hai. Key check karo."
                    429 -> "Gemini ki free usage limit abhi poori ho gayi hai. Thodi der baad try karo."
                    else -> "Gemini server error ($code). ${message.orEmpty().take(140)}"
                }
            }
            val root = JSONObject(response)
            root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                ?.takeIf { it.isNotBlank() } ?: "Gemini se khaali response aaya. Dobara bolo."
        } catch (e: Exception) {
            "Internet ya Gemini connection nahi mil raha. Local commands abhi bhi chal sakti hain."
        } finally {
            connection?.disconnect()
        }
    }
}
