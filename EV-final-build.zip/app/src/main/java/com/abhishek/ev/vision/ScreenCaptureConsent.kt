package com.abhishek.ev.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager

/**
 * Starts the Android system consent flow for screen capture.
 * The activity must call createScreenCaptureIntent() and handle the returned result.
 * Screen capture cannot start silently or without the user's approval.
 */
class ScreenCaptureConsent(private val context: Context) {
    fun consentIntent(): Intent {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return manager.createScreenCaptureIntent()
    }
}
