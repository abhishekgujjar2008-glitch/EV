package com.abhishek.ev.vision

import android.content.Context
import android.content.Intent
import android.provider.MediaStore

/** Privacy-preserving camera entry point; opens the system camera instead of covert capture. */
class CameraVisionLauncher(private val context: Context) {
    fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
