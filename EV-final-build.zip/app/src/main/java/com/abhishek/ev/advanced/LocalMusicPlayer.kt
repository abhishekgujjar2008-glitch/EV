package com.abhishek.ev.advanced

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri

/** Plays user-selected local audio. The app must obtain a content Uri via Android's file picker. */
class LocalMusicPlayer(private val context: Context) {
    private var player: MediaPlayer? = null

    fun play(uri: Uri, onError: (String) -> Unit = {}) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(context, uri)
            setOnPreparedListener { it.start() }
            setOnErrorListener { _, what, extra ->
                onError("Playback error ($what/$extra)")
                true
            }
            prepareAsync()
        }
    }

    fun pause() { player?.takeIf { it.isPlaying }?.pause() }
    fun resume() { player?.takeIf { !it.isPlaying }?.start() }
    fun stop() { player?.runCatching { stop() }; player?.release(); player = null }
}
