package com.abhishek.ev.information

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

data class NewsItem(val title: String, val link: String)

class NewsFeed {
    /** Fetches an RSS feed selected by the user. XML parsing is deliberately conservative. */
    suspend fun fetchRss(feedUrl: String): Result<List<NewsItem>> = withContext(Dispatchers.IO) {
        runCatching {
            require(feedUrl.startsWith("https://")) { "Only HTTPS RSS feeds are allowed" }
            val xml = URL(feedUrl).openConnection().apply {
                connectTimeout = 8000
                readTimeout = 10000
            }.getInputStream().bufferedReader().use { it.readText() }
            val itemRegex = Regex("<item[\\s\\S]*?<title><!\\[CDATA\\[(.*?)]]></title>[\\s\\S]*?<link>(.*?)</link>[\\s\\S]*?</item>", RegexOption.IGNORE_CASE)
            itemRegex.findAll(xml).take(15).map {
                NewsItem(it.groupValues[1].trim(), it.groupValues[2].trim())
            }.toList()
        }
    }
}
