package com.abhishek.ev.communication

/**
 * Stores an in-memory family priority policy only.
 * Persistent contacts/notification exceptions must be configured by the user in Android settings.
 */
data class PriorityContact(val displayName: String, val normalizedNumber: String)

class FamilyPriority {
    private val priority = linkedMapOf<String, PriorityContact>()

    fun add(contact: PriorityContact) { priority[contact.normalizedNumber] = contact }
    fun remove(number: String) { priority.remove(number) }
    fun isPriority(number: String): Boolean = priority.containsKey(number)
    fun all(): List<PriorityContact> = priority.values.toList()
}
