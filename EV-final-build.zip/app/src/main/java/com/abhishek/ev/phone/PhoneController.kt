package com.abhishek.ev.phone

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings

/** Result of a phone action. [ok] is true only when the action really happened. */
data class ActionResult(val ok: Boolean, val message: String)

class PhoneController(private val ctx: Context) {

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    fun torch(on: Boolean): ActionResult = try {
        val id = camera.cameraIdList.firstOrNull {
            camera.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActionResult(false, "Is phone mein torch nahi mila.")
        camera.setTorchMode(id, on)
        ActionResult(true, if (on) "Torch on kar di." else "Torch band kar di.")
    } catch (e: Exception) {
        ActionResult(false, "Torch control nahi ho paya.")
    }

    fun volumeStep(up: Boolean): ActionResult {
        val before = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        val after = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        return if (before != after) ActionResult(true, if (up) "Volume badha diya." else "Volume kam kar diya.")
        else ActionResult(false, if (up) "Volume pehle se maximum hai." else "Volume pehle se minimum hai.")
    }

    fun setVolumePercent(percent: Int): ActionResult {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * percent.coerceIn(0, 100) / 100f).toInt()
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == target)
            ActionResult(true, "Volume $percent percent kar diya.")
        else ActionResult(false, "Volume set nahi ho paya.")
    }

    fun setBrightnessPercent(percent: Int): ActionResult {
        if (!Settings.System.canWrite(ctx)) {
            openIntent(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return ActionResult(false, "Brightness ke liye permission chahiye. Settings khol di hai, EV ko allow kar do.")
        }
        val value = (255 * percent.coerceIn(0, 100) / 100f).toInt()
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            val now = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, -1)
            if (now == value) ActionResult(true, "Brightness $percent percent kar di.")
            else ActionResult(false, "Brightness change nahi hui.")
        } catch (e: Exception) {
            ActionResult(false, "Brightness set nahi ho payi.")
        }
    }

    fun batteryStatus(): ActionResult {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return ActionResult(true, "Battery $pct percent hai${if (charging) ", aur charge ho rahi hai." else "."}")
    }

    fun deviceInfo(): ActionResult =
        ActionResult(true, "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}.")

    /** Wi-Fi and Bluetooth can't be toggled directly on modern Android, so open their settings. */
    fun openSettings(kind: String): ActionResult {
        val action = when (kind) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "dnd" -> Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (openIntent(Intent(action))) ActionResult(true, "Settings khol di.")
        else ActionResult(false, "Settings nahi khul payi.")
    }

    fun openCamera(): ActionResult =
        if (openIntent(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))) ActionResult(true, "Camera khol diya.")
        else ActionResult(false, "Camera nahi khul paya.")

    fun launchApp(spokenName: String): ActionResult {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val wanted = spokenName.trim().lowercase()
        val match = pm.queryIntentActivities(query, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().let { label -> label == wanted || label.contains(wanted) }
        } ?: return ActionResult(false, "$spokenName naam ka app nahi mila.")
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return ActionResult(false, "$spokenName khul nahi paya.")
        return if (openIntent(launch)) ActionResult(true, "${match.loadLabel(pm)} khol diya.")
        else ActionResult(false, "$spokenName khul nahi paya.")
    }

    private fun openIntent(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}
