package com.abhishek.ev.brain

import java.util.Calendar

sealed class Command {
    data class Torch(val on: Boolean) : Command()
    data class Volume(val up: Boolean) : Command()
    data class VolumePercent(val percent: Int) : Command()
    data class Brightness(val percent: Int) : Command()
    data class OpenApp(val name: String) : Command()
    data class OpenSettings(val kind: String) : Command()
    object OpenCamera : Command()
    object Battery : Command()
    object DeviceInfo : Command()
    data class SetReminder(val text: String, val atMs: Long, val repeat: String) : Command()
    object Stop : Command()          // "chup", "stop"
    object Sleep : Command()
    object Unknown : Command()
}

/**
 * Local, offline command recognition (Hindi / Hinglish / English).
 * Returns the text with the wake word removed via [stripWake].
 */
object CommandParser {

    private val wakeWords = listOf("hey ev", "hello ev", "ev wake up", "ev")

    /** Returns the part after the wake word, or null if no wake word was heard. */
    fun stripWake(heard: String): String? {
        val t = heard.lowercase().trim()
        for (w in wakeWords) {
            val i = Regex("\\b${Regex.escape(w)}\\b").find(t)?.range?.last
            if (i != null) return t.substring(i + 1).trim()
        }
        return null
    }

    fun parse(raw: String, now: Calendar = Calendar.getInstance()): Command {
        val t = raw.lowercase().trim().trimEnd('.', '!', '?')
        if (t.isEmpty()) return Command.Unknown

        if (Regex("\\b(chup|stop|ruko|ruk ja|quiet)\\b").containsMatchIn(t) && t.length < 12) return Command.Stop
        if (Regex("(so ja|sleep|sleep mode)").containsMatchIn(t)) return Command.Sleep

        // chained: "chup, youtube kholo" -> parse the remainder
        val cleaned = t.replace(Regex("^(chup|stop|ruko)[ ,]+"), "")

        if (Regex("torch|flashlight|flash light").containsMatchIn(cleaned)) {
            val off = Regex("\\b(off|band|bandh|bujha)\\b").containsMatchIn(cleaned)
            return Command.Torch(!off)
        }

        if (Regex("brightness").containsMatchIn(cleaned)) {
            percent(cleaned)?.let { return Command.Brightness(it) }
        }

        if (Regex("volume|awaaz|awaz").containsMatchIn(cleaned)) {
            percent(cleaned)?.let { return Command.VolumePercent(it) }
            val down = Regex("kam|down|low|ghata|decrease|lower").containsMatchIn(cleaned)
            val up = Regex("badha|badhao|zyada|jyada|up|increase|high|raise").containsMatchIn(cleaned)
            if (down || up) return Command.Volume(up && !down)
        }

        if (Regex("battery").containsMatchIn(cleaned)) return Command.Battery
        if (Regex("device info|phone info|phone ki jaankari").containsMatchIn(cleaned)) return Command.DeviceInfo

        if (Regex("camera").containsMatchIn(cleaned) && Regex("khol|open|chalu|start").containsMatchIn(cleaned))
            return Command.OpenCamera

        if (Regex("settings?").containsMatchIn(cleaned) && Regex("khol|open").containsMatchIn(cleaned)) {
            val kind = when {
                "bluetooth" in cleaned -> "bluetooth"
                Regex("wi-?fi|wifi").containsMatchIn(cleaned) -> "wifi"
                "display" in cleaned -> "display"
                "sound" in cleaned -> "sound"
                "battery" in cleaned -> "battery"
                Regex("dnd|do not disturb").containsMatchIn(cleaned) -> "dnd"
                else -> "main"
            }
            return Command.OpenSettings(kind)
        }

        if (Regex("(wi-?fi|bluetooth)").containsMatchIn(cleaned) && Regex("on|off|band|chalu").containsMatchIn(cleaned))
            return Command.OpenSettings(if ("bluetooth" in cleaned) "bluetooth" else "wifi")

        parseReminder(cleaned, now)?.let { return it }

        val open = Regex("^(.+?)\\s+(kholo|khol do|khol|open|chalao|launch)$").find(cleaned)
            ?: Regex("^(open|launch)\\s+(.+)$").find(cleaned)
        if (open != null) {
            val name = if (open.groupValues[1] in listOf("open", "launch")) open.groupValues[2] else open.groupValues[1]
            return Command.OpenApp(name.trim())
        }

        return Command.Unknown
    }

    private fun percent(t: String): Int? =
        Regex("(\\d{1,3})\\s*(percent|%|pratishat|prtishat)?").find(t)?.groupValues?.get(1)?.toIntOrNull()
            ?.takeIf { it in 0..100 }

    private fun parseReminder(t: String, now: Calendar): Command? {
        if (!Regex("yaad dil|remind|reminder").containsMatchIn(t)) return null

        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(baje|am|pm)?").find(t) ?: return null
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (hour > 23 || minute > 59) return null

        val evening = Regex("shaam|sham|raat|evening|night|pm|dopahar|afternoon").containsMatchIn(t)
        if (evening && hour in 1..11) hour += 12

        val cal = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (Regex("\\bkal\\b|tomorrow").containsMatchIn(t)) cal.add(Calendar.DAY_OF_YEAR, 1)
        else if (cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 1)

        val repeat = when {
            Regex("har din|roz|daily|every day").containsMatchIn(t) -> "DAILY"
            Regex("har (sunday|monday|tuesday|wednesday|thursday|friday|saturday)|weekly").containsMatchIn(t) -> "WEEKLY"
            else -> "NONE"
        }

        val what = t.replace(Regex("(mujhe|mujhko|ko|kal|subah|shaam|sham|raat|baje|yaad dilana|yaad dila do|remind me to|remind me|reminder|\\d{1,2}(:\\d{2})?)"), " ")
            .replace(Regex("\\s+"), " ").trim().ifEmpty { "reminder" }
        return Command.SetReminder(what, cal.timeInMillis, repeat)
    }
}
