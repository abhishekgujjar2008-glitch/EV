package com.abhishek.ev.voice

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.abhishek.ev.*
import com.abhishek.ev.brain.Command
import com.abhishek.ev.brain.CommandParser
import com.abhishek.ev.brain.EvMemory
import com.abhishek.ev.brain.EvConversation
import com.abhishek.ev.brain.GeminiClient
import com.abhishek.ev.phone.ActionResult
import com.abhishek.ev.phone.PhoneController
import com.abhishek.ev.reminders.EvDatabase
import com.abhishek.ev.reminders.Reminder
import com.abhishek.ev.reminders.ReminderScheduler
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Foreground service: listens for "EV ...", runs the command locally, speaks the result.
 * Barge-in: while EV is speaking, partial speech containing the wake word stops TTS at once.
 */
class VoiceService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var running = false
    private var conversationUntil = 0L   // after a wake word, follow-up commands work without it for a few seconds
    private var errorStreak = 0
    private var lastCommandText = ""

    private lateinit var phone: PhoneController

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY
        running = true
        phone = PhoneController(applicationContext)
        startAsForeground()
        initTts()
        initRecognizer()
        EvState.setRunning(true)
        listen()
        return START_STICKY
    }

    // ---------- foreground notification (visible microphone indicator) ----------
    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "EV listening", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("EV is listening")
            .setContentText("Microphone active. Say \"EV ...\"")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    // ---------- text to speech ----------
    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return@TextToSpeech
                val hi = t.setLanguage(Locale("hi", "IN"))
                if (hi == TextToSpeech.LANG_MISSING_DATA || hi == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale("en", "IN"))
                }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { main.post { speaking = true; EvState.setPhase(EvPhase.SPEAKING) } }
                    override fun onDone(id: String?) { main.post { speaking = false; EvState.setPhase(EvPhase.LISTENING) } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { speaking = false; EvState.setPhase(EvPhase.LISTENING) } }
                })
                ttsReady = true
                say("Namaste Abhishek, main sun raha hoon.")
            }
        }
    }

    private fun say(text: String) {
        EvState.add(ChatLine(false, text))
        if (!ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ev-${SystemClock.uptimeMillis()}")
    }

    private fun interruptSpeech() {
        if (speaking) {
            tts?.stop()
            speaking = false
            EvState.setPhase(EvPhase.LISTENING)
        }
    }

    // ---------- speech recognition ----------
    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Is phone par speech recognition available nahi hai.")
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
    }

    private fun listen() {
        if (!running) return
        val r = recognizer ?: return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")          // handles Hinglish spoken in Roman letters best
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)        // use offline model if installed
        }
        if (!speaking) EvState.setPhase(EvPhase.LISTENING)
        try { r.startListening(i) } catch (e: Exception) { restartListening(500) }
    }

    private fun restartListening(delayMs: Long) {
        main.postDelayed({ if (running) { recognizer?.cancel(); listen() } }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(partial: Bundle?) {
            val text = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            // Barge-in: user says "EV ..." while EV is talking -> stop talking immediately.
            if (speaking && CommandParser.stripWake(text) != null) interruptSpeech()
        }

        override fun onResults(results: Bundle?) {
            errorStreak = 0
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!heard.isNullOrBlank()) handleHeard(heard, SystemClock.elapsedRealtime())
            restartListening(50)
        }

        override fun onError(error: Int) {
            // NO_MATCH / SPEECH_TIMEOUT are normal when nobody speaks.
            errorStreak++
            val backoff = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000L
            else if (errorStreak > 5) 3000L else 200L
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                say("Microphone permission chahiye.")
                shutdown(); return
            }
            restartListening(backoff)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ---------- command handling ----------
    private fun handleHeard(heard: String, receivedAt: Long) {
        val afterWake = CommandParser.stripWake(heard)
        val inConversation = SystemClock.elapsedRealtime() < conversationUntil
        val commandText = afterWake ?: if (inConversation) heard else return   // ignore speech without wake word

        EvState.add(ChatLine(true, heard))
        interruptSpeech()
        conversationUntil = SystemClock.elapsedRealtime() + 8000

        if (commandText.isBlank()) { say("Haan Abhishek?"); return }
        lastCommandText = commandText.trim()

        EvState.setPhase(EvPhase.THINKING)
        val cmd = CommandParser.parse(commandText)
        scope.launch {
            val result = execute(cmd)
            EvState.setLatency(SystemClock.elapsedRealtime() - receivedAt)   // real measured time, not a guess
            if (result != null) say(result.message)
        }
    }

    private suspend fun execute(cmd: Command): ActionResult? = when (cmd) {
        is Command.Torch -> phone.torch(cmd.on)
        is Command.Volume -> phone.volumeStep(cmd.up)
        is Command.VolumePercent -> phone.setVolumePercent(cmd.percent)
        is Command.Brightness -> phone.setBrightnessPercent(cmd.percent)
        is Command.OpenApp -> phone.launchApp(cmd.name)
        is Command.OpenSettings -> phone.openSettings(cmd.kind)
        Command.OpenCamera -> phone.openCamera()
        Command.Battery -> phone.batteryStatus()
        Command.DeviceInfo -> phone.deviceInfo()
        is Command.SetReminder -> saveReminder(cmd)
        Command.Stop -> null                 // speech was already stopped in handleHeard
        Command.Sleep -> { say("Theek hai Abhishek, main so raha hoon."); main.postDelayed({ shutdown() }, 2500); null }
        Command.Unknown -> answerWithBrain(lastCommandText)
    }

    private suspend fun answerWithBrain(text: String): ActionResult = withContext(Dispatchers.IO) {
        val db = EvDatabase.get(applicationContext)
        val clean = text.trim()
        val lower = clean.lowercase(Locale.ROOT)

        // Explicit memory controls. The assistant never silently invents personal facts.
        if (lower.startsWith("yaad rakho") || lower.startsWith("remember that")) {
            val payload = clean.replace(Regex("(?i)^yaad\\s+rakho\\s*[:,-]?\\s*"), "")
                .replace(Regex("(?i)^remember\\s+that\\s*"), "").trim()
            if (payload.isBlank()) return@withContext ActionResult(false, "Kya yaad rakhna hai? Dobara bolo.")
            val key = if (payload.contains(":")) payload.substringBefore(":").trim() else "note"
            val value = if (payload.contains(":")) payload.substringAfter(":").trim() else payload
            if (key.isBlank() || value.isBlank()) return@withContext ActionResult(false, "Memory ko 'yaad rakho naam: detail' format mein bolo.")
            db.memories().deleteByKey(key)
            db.memories().insert(EvMemory(memoryKey = key, memoryValue = value))
            return@withContext ActionResult(true, "Theek hai, maine yaad rakh liya: $value")
        }
        if (lower.contains("kya yaad") || lower.contains("meri memory") || lower == "batao") {
            val memories = db.memories().all()
            val answer = if (memories.isEmpty()) "Abhi meri memory khaali hai." else memories.take(12).joinToString(". ") { "${it.memoryKey}: ${it.memoryValue}" }
            return@withContext ActionResult(true, answer)
        }
        if (lower.startsWith("bhool jao") || lower.startsWith("forget memory")) {
            val key = clean.replace(Regex("(?i)^bhool\\s+jao\\s*[:,-]?\\s*"), "")
                .replace(Regex("(?i)^forget\\s+memory\\s*"), "").trim()
            if (key.isBlank()) return@withContext ActionResult(false, "Kis memory ko bhoolna hai? Uska naam bolo.")
            db.memories().deleteByKey(key)
            return@withContext ActionResult(true, "Agar '$key' naam ki memory thi to delete kar di.")
        }

        val memories = db.memories().all().take(30)
        val memoryText = memories.joinToString("\n") { "${it.memoryKey}: ${it.memoryValue}" }
        val history = db.conversations().recent(10).asReversed().map { it.role to it.message }
        db.conversations().add(EvConversation(role = "user", message = clean))
        val answer = GeminiClient(applicationContext).ask(clean, memoryText, history)
        db.conversations().add(EvConversation(role = "assistant", message = answer))
        db.conversations().deleteBefore(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000)
        ActionResult(true, answer)
    }

    private suspend fun saveReminder(c: Command.SetReminder): ActionResult = withContext(Dispatchers.IO) {
        val dao = EvDatabase.get(applicationContext).reminders()
        val id = dao.insert(Reminder(text = c.text, triggerAtMs = c.atMs, repeat = c.repeat))
        val scheduled = ReminderScheduler.schedule(applicationContext, Reminder(id, c.text, c.atMs, c.repeat))
        if (!scheduled) {
            dao.delete(id)
            ActionResult(false, "Reminder set nahi ho paya. Alarm permission check karo.")
        } else {
            val whenText = SimpleDateFormat("EEE d MMM, h:mm a", Locale.ENGLISH).format(c.atMs)
            ActionResult(true, "Theek hai, $whenText par yaad dilaunga.")
        }
    }

    private fun shutdown() {
        running = false
        EvState.setRunning(false)
        EvState.setPhase(EvPhase.IDLE)
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) shutdown()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "ev_voice"
        const val ACTION_STOP = "com.abhishek.ev.STOP"

        fun start(ctx: Context) =
            ctx.startForegroundService(Intent(ctx, VoiceService::class.java))

        fun stop(ctx: Context) =
            ctx.startService(Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP))
    }
}
