package com.abhishek.ev.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.room.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerAtMs: Long,
    val repeat: String = "NONE" // NONE, DAILY, WEEKLY
)

@Dao
interface ReminderDao {
    @Insert suspend fun insert(r: Reminder): Long
    @Update suspend fun update(r: Reminder)
    @Query("DELETE FROM reminders WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT * FROM reminders WHERE id = :id") suspend fun get(id: Long): Reminder?
    @Query("SELECT * FROM reminders ORDER BY triggerAtMs") suspend fun all(): List<Reminder>
}

@Database(entities = [Reminder::class, com.abhishek.ev.brain.EvMemory::class, com.abhishek.ev.brain.EvConversation::class], version = 2, exportSchema = false)
abstract class EvDatabase : RoomDatabase() {
    abstract fun reminders(): ReminderDao
    abstract fun memories(): com.abhishek.ev.brain.MemoryDao
    abstract fun conversations(): com.abhishek.ev.brain.ConversationDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS ev_memories (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, memoryKey TEXT NOT NULL, memoryValue TEXT NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS ev_conversations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, role TEXT NOT NULL, message TEXT NOT NULL, createdAt INTEGER NOT NULL)")
            }
        }
        @Volatile private var inst: EvDatabase? = null
        fun get(ctx: Context): EvDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, EvDatabase::class.java, "ev.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}

object ReminderScheduler {
    const val CHANNEL = "ev_reminders"

    /** Returns true only if the alarm was really scheduled. */
    fun schedule(ctx: Context, r: Reminder): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, r.id)
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAtMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAtMs, pi) // inexact fallback
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun cancel(ctx: Context, id: Long) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx, id))
    }

    private fun pending(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = EvDatabase.get(ctx).reminders()
                val r = dao.get(id) ?: return@launch
                notify(ctx, r)
                val step = when (r.repeat) {
                    "DAILY" -> 24L * 60 * 60 * 1000
                    "WEEKLY" -> 7L * 24 * 60 * 60 * 1000
                    else -> 0L
                }
                if (step > 0) {
                    val next = r.copy(triggerAtMs = r.triggerAtMs + step)
                    dao.update(next)
                    ReminderScheduler.schedule(ctx, next)
                } else dao.delete(r.id)
            } finally {
                pending.finish()
            }
        }
    }

    private fun notify(ctx: Context, r: Reminder) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(ReminderScheduler.CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = NotificationCompat.Builder(ctx, ReminderScheduler.CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("EV Reminder")
            .setContentText("Abhishek, ${r.text}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify(r.id.toInt(), n)
    }
}

/** Re-schedules all saved reminders after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val now = System.currentTimeMillis()
                EvDatabase.get(ctx).reminders().all().filter { it.triggerAtMs > now || it.repeat != "NONE" }
                    .forEach { ReminderScheduler.schedule(ctx, it) }
            } finally {
                pending.finish()
            }
        }
    }
}
