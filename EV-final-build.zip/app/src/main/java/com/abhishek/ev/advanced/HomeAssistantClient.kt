package com.abhishek.ev.advanced

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional Home Assistant REST connector.
 * Requires the user to configure their own HTTPS base URL and long-lived token securely.
 * Do not hardcode tokens in source control or logs.
 */
class HomeAssistantClient(
    private val baseUrl: String,
    private val tokenProvider: suspend () -> String
) {
    suspend fun callService(domain: String, service: String, entityId: String): Result<Int> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(baseUrl.startsWith("https://")) { "Use HTTPS for remote Home Assistant" }
                require(domain.matches(Regex("[a-z_]+")) && service.matches(Regex("[a-z_]+")))
                require(entityId.matches(Regex("[a-z_]+\\.[a-zA-Z0-9_]+")))
                val token = tokenProvider()
                require(token.isNotBlank()) { "Home Assistant token is not configured" }
                val url = URL("${baseUrl.trimEnd('/')}/api/services/$domain/$service")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 10000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", "application/json")
                }
                connection.outputStream.use {
                    it.write("{\\"entity_id\\":\\"$entityId\\"}".toByteArray())
                }
                val code = connection.responseCode
                connection.disconnect()
                code
            }
        }
}
