package com.abhishek.ev.advanced

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Opens Android's notification-listener access page; user must enable EV manually. */
class NotificationAccessInfo(private val context: Context) {
    fun openSettings() {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
