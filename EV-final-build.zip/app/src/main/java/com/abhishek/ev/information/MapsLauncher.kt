package com.abhishek.ev.information

import android.content.Context
import android.content.Intent
import android.net.Uri

class MapsLauncher(private val context: Context) {
    fun navigateTo(query: String) {
        val uri = Uri.parse("google.navigation:q=${Uri.encode(query)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(context.packageManager) == null) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}")))
        } else context.startActivity(intent)
    }
}
