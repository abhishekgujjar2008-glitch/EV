package com.abhishek.ev

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class EvPhase { IDLE, LISTENING, THINKING, SPEAKING }

data class ChatLine(val fromUser: Boolean, val text: String)

/** Shared state between the voice service and the UI. */
object EvState {
    private val _phase = MutableStateFlow(EvPhase.IDLE)
    val phase: StateFlow<EvPhase> = _phase

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running

    private val _lines = MutableStateFlow<List<ChatLine>>(emptyList())
    val lines: StateFlow<List<ChatLine>> = _lines

    /** Measured time from recognised text to command finished (ms). */
    private val _lastLatencyMs = MutableStateFlow<Long?>(null)
    val lastLatencyMs: StateFlow<Long?> = _lastLatencyMs

    fun setPhase(p: EvPhase) { _phase.value = p }
    fun setRunning(r: Boolean) { _running.value = r }
    fun setLatency(ms: Long) { _lastLatencyMs.value = ms }
    fun add(line: ChatLine) { _lines.value = (_lines.value + line).takeLast(30) }
}
