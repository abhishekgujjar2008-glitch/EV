package com.abhishek.ev.brain

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query

@Entity(tableName = "ev_memories")
data class EvMemory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memoryKey: String,
    val memoryValue: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(memory: EvMemory): Long
    @Query("SELECT * FROM ev_memories ORDER BY updatedAt DESC") suspend fun all(): List<EvMemory>
    @Query("SELECT * FROM ev_memories WHERE memoryKey LIKE '%' || :query || '%' OR memoryValue LIKE '%' || :query || '%' ORDER BY updatedAt DESC") suspend fun search(query: String): List<EvMemory>
    @Query("DELETE FROM ev_memories WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM ev_memories WHERE memoryKey = :key") suspend fun deleteByKey(key: String)
}

@Entity(tableName = "ev_conversations")
data class EvConversation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val message: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ConversationDao {
    @Insert suspend fun add(item: EvConversation)
    @Query("SELECT role, message FROM ev_conversations ORDER BY createdAt DESC LIMIT :limit") suspend fun recent(limit: Int = 12): List<ConversationRow>
    @Query("DELETE FROM ev_conversations WHERE createdAt < :before") suspend fun deleteBefore(before: Long)
}

data class ConversationRow(val role: String, val message: String)
