package com.abhishek.ev.brain

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores the user's Gemini key encrypted on this device. Never logs or uploads the key. */
object SecureKeyStore {
    private const val FILE = "ev_secure_settings"
    private const val KEY = "gemini_api_key"

    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        FILE,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun get(context: Context): String = runCatching { prefs(context).getString(KEY, "").orEmpty() }.getOrDefault("")
    fun save(context: Context, value: String) { prefs(context).edit().putString(KEY, value.trim()).apply() }
    fun clear(context: Context) { prefs(context).edit().remove(KEY).apply() }
}
