package com.abhishek.ev

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.abhishek.ev.voice.VoiceService
import com.abhishek.ev.brain.SecureKeyStore

private val Bg = Color(0xFF05080F)
private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF3B82F6)
private val Panel = Color(0xFF0D1522)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                EvScreen()
            }
        }
    }
}

@Composable
fun EvScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val phase by EvState.phase.collectAsStateWithLifecycle()
    val running by EvState.running.collectAsStateWithLifecycle()
    val lines by EvState.lines.collectAsStateWithLifecycle()
    val latency by EvState.lastLatencyMs.collectAsStateWithLifecycle()

    var micOk by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        micOk = r[Manifest.permission.RECORD_AUDIO] == true
        if (micOk) VoiceService.start(ctx)
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("EV", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(
            when (phase) {
                EvPhase.IDLE -> "Sleeping"
                EvPhase.LISTENING -> "Listening"
                EvPhase.THINKING -> "Thinking"
                EvPhase.SPEAKING -> "Speaking"
            },
            color = Color(0xFF94A3B8)
        )

        Spacer(Modifier.height(16.dp))
        EvCore(phase, Modifier.size(220.dp))
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (running) VoiceService.stop(ctx)
                else {
                    val perms = buildList {
                        add(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                    }.toTypedArray()
                    permLauncher.launch(perms)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF7F1D1D) else Blue)
        ) { Text(if (running) "Stop EV" else "Start EV") }

        latency?.let {
            Text("Last command latency: $it ms", color = Color(0xFF64748B), fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp))
        }

        Spacer(Modifier.height(12.dp))
        SetupRow(ctx)
        Spacer(Modifier.height(8.dp))
        GeminiKeyPanel(ctx)
        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(lines) { l ->
                Box(
                    Modifier.fillMaxWidth(),
                    contentAlignment = if (l.fromUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Text(
                        l.text,
                        color = Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            .background(if (l.fromUser) Blue.copy(alpha = 0.35f) else Panel)
                            .padding(10.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun GeminiKeyPanel(ctx: Context) {
    var key by remember { mutableStateOf(SecureKeyStore.get(ctx)) }
    var status by remember { mutableStateOf(if (key.isBlank()) "Gemini AI: API key required" else "Gemini AI: API key saved on this phone") }
    var showKey by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("PHASE 2 · GEMINI BRAIN", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Gemini API key") },
                visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") }
                Button(onClick = {
                    status = runCatching {
                        if (key.isBlank()) SecureKeyStore.clear(ctx) else SecureKeyStore.save(ctx, key)
                        if (key.isBlank()) "API key removed" else "API key saved encrypted on this phone"
                    }.getOrElse { "Secure storage error: ${it.message ?: "unknown"}" }
                }) { Text("Save key") }
            }
            Text(status, color = Color(0xFF94A3B8), fontSize = 11.sp)
            Text("Key sirf is device par encrypted save hoti hai. EV ke AI replies ke liye internet zaroori hai.", color = Color(0xFF64748B), fontSize = 10.sp)
        }
    }
}

/** Optional one-time permissions shown as shortcuts. */
@Composable
private fun SetupRow(ctx: Context) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Brightness access", fontSize = 12.sp) }

        OutlinedButton(onClick = {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }) { Text("Exact alarms", fontSize = 12.sp) }
    }
}

/** Animated central EV core: pulses by phase. */
@Composable
fun EvCore(phase: EvPhase, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "core")
    val speed = when (phase) {
        EvPhase.IDLE -> 4000
        EvPhase.LISTENING -> 1800
        EvPhase.THINKING -> 700
        EvPhase.SPEAKING -> 1000
    }
    val pulse by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(speed, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(if (phase == EvPhase.THINKING) 1500 else 6000, easing = LinearEasing)),
        label = "s"
    )
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val base = size.minDimension / 2
        for (i in 0..2) {
            val p = (pulse + i / 3f) % 1f
            drawCircle(Cyan.copy(alpha = (1f - p) * 0.35f), radius = base * (0.45f + p * 0.55f), center = c, style = Stroke(2f))
        }
        drawCircle(
            Brush.radialGradient(listOf(Cyan, Blue, Color.Transparent), center = c, radius = base * 0.5f),
            radius = base * 0.5f, center = c
        )
        drawArc(
            Cyan, startAngle = spin, sweepAngle = 90f, useCenter = false,
            topLeft = Offset(c.x - base * 0.7f, c.y - base * 0.7f),
            size = androidx.compose.ui.geometry.Size(base * 1.4f, base * 1.4f), style = Stroke(5f)
        )
    }
}
